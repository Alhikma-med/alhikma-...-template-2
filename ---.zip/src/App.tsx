import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";

type Language = "ar" | "en";

type ProductCategory = {
  key: string;
  title: string;
  subtitle: string;
  items: string[];
};

type ManagedProduct = {
  id: string;
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  itemsAr: string[];
  itemsEn: string[];
};

type ProductDraft = {
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  itemsAr: string;
  itemsEn: string;
};

type WorkImage = {
  id: string;
  src: string;
};

const slideImages = [
  "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1800&q=80",
  "https://images.unsplash.com/photo-1551076805-e1866033e561?auto=format&fit=crop&w=1800&q=80",
  "https://images.unsplash.com/photo-1579684385127-1ecd15d5bfbcc?auto=format&fit=crop&w=1800&q=80",
];

const portalPassword = "hikma2026";
const adminPassword = "hikma-admin";
const productsStorageKey = "hikma-products-v1";
const partnersStorageKey = "hikma-partners-v1";
const logoStorageKey = "hikma-logo-v1";
const workImagesStorageKey = "hikma-work-images-v1";

const defaultProducts: ManagedProduct[] = [
  {
    id: "steam",
    titleAr: "أنظمة التعقيم البخاري",
    titleEn: "Steam Sterilizers",
    subtitleAr: "Steam Sterilizers",
    subtitleEn: "Large and medium capacity systems",
    itemsAr: [
      "سعات كبيرة: 600 و800 لتر لغرف التعقيم المركزية.",
      "سعات متوسطة وصغيرة: 100 و200 لتر للمراكز والعيادات.",
      "حلول مطابقة لمعايير EN 285 ومتطلبات وزارة الصحة.",
    ],
    itemsEn: [
      "Large capacities: 600L and 800L for central sterile departments.",
      "Medium and compact capacities: 100L and 200L for clinics and health centers.",
      "Aligned with EN 285 standards and local hospital requirements.",
    ],
  },
  {
    id: "washer",
    titleAr: "أجهزة الغسل والتعقيم",
    titleEn: "Washer Disinfectors",
    subtitleAr: "Washer Disinfectors",
    subtitleEn: "Surgical instrument washing and disinfection",
    itemsAr: [
      "موديلات غسل الأدوات الجراحية بسعات 300 و500 لتر.",
      "برامج ذكية لضبط الحرارة والوقت لكل نوع أداة.",
      "نتائج موثقة تدعم جاهزية أقسام العمليات.",
    ],
    itemsEn: [
      "Instrument washer models with 300L and 500L capacity.",
      "Smart cycle control for heat and time per instrument type.",
      "Documented results that support operating room readiness.",
    ],
  },
  {
    id: "plasma",
    titleAr: "أجهزة التعقيم بدرجات حرارة منخفضة",
    titleEn: "Low-Temperature Plasma Sterilizers",
    subtitleAr: "Plasma Sterilizers",
    subtitleEn: "Advanced solutions for heat-sensitive equipment",
    itemsAr: [
      "حل متقدم للأجهزة الحساسة للحرارة والرطوبة.",
      "دورات تعقيم سريعة مع كفاءة تشغيل عالية.",
      "ملائمة للمشافي التي تحتاج مرونة تشغيل يومية.",
    ],
    itemsEn: [
      "Ideal for devices sensitive to heat and moisture.",
      "Efficient and fast sterilization cycles.",
      "Built for facilities requiring daily operational flexibility.",
    ],
  },
  {
    id: "incubators",
    titleAr: "حاضنات الأطفال",
    titleEn: "Infant Incubators",
    subtitleAr: "Incubator Systems",
    subtitleEn: "Advanced neonatal care units",
    itemsAr: [
      "تحكم دقيق في درجة الحرارة والرطوبة.",
      "أنظمة أمان ومراقبة حيوية متطورة.",
      "تصميم مريح يسهل التعامل مع الرضع.",
    ],
    itemsEn: [
      "Precise temperature and humidity control.",
      "Advanced safety and vital monitoring systems.",
      "Ergonomic design for easy infant handling.",
    ],
  },
  {
    id: "water",
    titleAr: "أنظمة معالجة المياه",
    titleEn: "Water Treatment Systems",
    subtitleAr: "Water Treatment Systems",
    subtitleEn: "Hospital-grade RO infrastructure",
    itemsAr: [
      "محطات RO مخصصة لاحتياجات المستشفيات السورية.",
      "استقرار في جودة المياه لضمان أداء أجهزة التعقيم.",
      "تصميم قابل للتوسعة حسب حجم المنشأة الصحية.",
    ],
    itemsEn: [
      "RO treatment stations tailored for hospital workflows.",
      "Stable water quality to protect sterilization performance.",
      "Scalable design based on facility size and demand.",
    ],
  },
  {
    id: "consumables",
    titleAr: "المستهلكات الطبية",
    titleEn: "Medical Consumables",
    subtitleAr: "Medical Consumables",
    subtitleEn: "Operational accessories and consumables",
    itemsAr: [
      "ماكينات إغلاق الأكياس Sealing Machines.",
      "مستلزمات تشغيل أصلية وتوافق كامل مع الأجهزة.",
      "سلاسل توريد مستقرة وموثوقة للمناقصات الدورية.",
    ],
    itemsEn: [
      "Sealing machines and related packaging accessories.",
      "Original consumables with full device compatibility.",
      "Reliable supply flow for routine and tender-based procurement.",
    ],
  },
];

const defaultPartners = ["Shinva", "Laoken", "Medical Park", "Global Care", "CSSD Solutions"];

const defaultCompanyLogo =
  "https://images.unsplash.com/photo-1583912267550-d4bcdd7e9d9d?auto=format&fit=crop&w=500&q=80";

const defaultWorkImages: WorkImage[] = [
  {
    id: "work-1",
    src: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=1400&q=80",
  },
  {
    id: "work-2",
    src: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1400&q=80",
  },
  {
    id: "work-3",
    src: "https://images.unsplash.com/photo-1579154204601-01588f351e67?auto=format&fit=crop&w=1400&q=80",
  },
];

const emptyDraft: ProductDraft = {
  titleAr: "",
  titleEn: "",
  subtitleAr: "",
  subtitleEn: "",
  itemsAr: "",
  itemsEn: "",
};

const buildLocaleProducts = (products: ManagedProduct[], language: Language): ProductCategory[] =>
  products.map((product) => {
    if (language === "ar") {
      return {
        key: product.id,
        title: product.titleAr,
        subtitle: product.subtitleAr,
        items: product.itemsAr,
      };
    }

    return {
      key: product.id,
      title: product.titleEn,
      subtitle: product.subtitleEn,
      items: product.itemsEn,
    };
  });

const createProductId = (value: string) => {
  const normalized = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

  return normalized || `product-${Date.now()}`;
};

const readFileAsDataUrl = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("file-read-failed"));
    reader.readAsDataURL(file);
  });

export function App() {
  const [language, setLanguage] = useState<Language>("ar");
  const [activeSlide, setActiveSlide] = useState(0);
  const [activeProductKey, setActiveProductKey] = useState(defaultProducts[0]?.id ?? "");
  const [portalInput, setPortalInput] = useState("");
  const [portalUnlocked, setPortalUnlocked] = useState(false);
  const [portalError, setPortalError] = useState(false);
  const [messageSent, setMessageSent] = useState(false);
  const [managedProducts, setManagedProducts] = useState<ManagedProduct[]>(defaultProducts);
  const [partners, setPartners] = useState<string[]>(defaultPartners);
  const [adminOpen, setAdminOpen] = useState(false);
  const [adminInput, setAdminInput] = useState("");
  const [adminError, setAdminError] = useState(false);
  const [adminAuthenticated, setAdminAuthenticated] = useState(false);
  const [newPartner, setNewPartner] = useState("");
  const [newWorkImage, setNewWorkImage] = useState("");
  const [productDraft, setProductDraft] = useState<ProductDraft>(emptyDraft);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [companyLogoUrl, setCompanyLogoUrl] = useState(defaultCompanyLogo);
  const [workImages, setWorkImages] = useState<WorkImage[]>(defaultWorkImages);

  useEffect(() => {
    const savedProducts = window.localStorage.getItem(productsStorageKey);
    if (savedProducts) {
      try {
        const parsed = JSON.parse(savedProducts) as ManagedProduct[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          setManagedProducts(parsed);
        }
      } catch {
        setManagedProducts(defaultProducts);
      }
    }

    const savedPartners = window.localStorage.getItem(partnersStorageKey);
    if (savedPartners) {
      try {
        const parsed = JSON.parse(savedPartners) as string[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          setPartners(parsed.filter((partner) => partner.toLowerCase() !== "nuve"));
        }
      } catch {
        setPartners(defaultPartners);
      }
    }

    const savedLogo = window.localStorage.getItem(logoStorageKey);
    if (savedLogo) {
      setCompanyLogoUrl(savedLogo);
    }

    const savedWorkImages = window.localStorage.getItem(workImagesStorageKey);
    if (savedWorkImages) {
      try {
        const parsed = JSON.parse(savedWorkImages) as WorkImage[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          setWorkImages(parsed.filter((item) => typeof item?.src === "string" && item.src.trim()));
        }
      } catch {
        setWorkImages(defaultWorkImages);
      }
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem(productsStorageKey, JSON.stringify(managedProducts));
  }, [managedProducts]);

  useEffect(() => {
    window.localStorage.setItem(partnersStorageKey, JSON.stringify(partners));
  }, [partners]);

  useEffect(() => {
    window.localStorage.setItem(logoStorageKey, companyLogoUrl);
  }, [companyLogoUrl]);

  useEffect(() => {
    window.localStorage.setItem(workImagesStorageKey, JSON.stringify(workImages));
  }, [workImages]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slideImages.length);
    }, 5000);

    return () => window.clearInterval(timer);
  }, []);

  const copy = useMemo(() => {
    const products = buildLocaleProducts(managedProducts, language);

    if (language === "ar") {
      return {
        dir: "rtl" as const,
        localeLabel: "English",
        brand: "شركة الحكمة للتجهيزات الطبية",
        nav: [
          ["partners", "شركاؤنا"],
          ["products", "المنتجات"],
          ["projects", "المشاريع"],
          ["about", "عن الشركة"],
          ["contact", "تواصل معنا"],
        ] as const,
        heroTitle: "شركة الحكمة",
        heroHeadline: "شريككم الموثوق في تجهيز المنشآت الطبية في سوريا",
        heroSubline:
          "الوكيل المعتمد لشركات Shinva وLaoken لتقديم أنظمة تعقيم متكاملة للمشافي والمراكز الصحية.",
        ctaPrimary: "استعرض المنتجات",
        ctaSecondary: "طلب استشارة",
        partnersTitle: "شركاؤنا",
        partnersSubline: "نمثل علامات عالمية موثوقة في قطاع التعقيم والتجهيزات الطبية.",
        aboutTitle: "عن الشركة",
        aboutBody:
          "شركة الحكمة مقرها إدلب، سوريا، وتعمل على ربط القطاع الصحي السوري بأحدث الحلول الطبية العالمية عبر التوريد والتركيب والدعم طويل الأمد.",
        visionTitle: "الرؤية",
        visionBody: "تقديم أحدث التكنولوجيا الطبية للمستشفيات والمراكز الصحية السورية مع التزام كامل بمعايير الجودة.",
        experienceTitle: "الخبرة والدعم",
        experienceBody:
          "نقدم تدريباً تقنياً متخصصاً للكوادر الطبية والهندسية، إضافة إلى دعم فني وصيانة دورية وقطع غيار أصلية.",
        managerTitle: "كلمة الإدارة",
        managerQuote:
          "تأسست شركة الحكمة لتكون الجسر الذي يربط القطاع الصحي في سوريا بأحدث الابتكارات الطبية العالمية. بصفتنا وكلاء معتمدين لعمالقة التصنيع مثل Shinva و Laoken، نلتزم بتوفير حلول تعقيم متكاملة تضمن أعلى معايير الأمان للمرضى والكوادر الطبية.",
        workTitle: "المشاريع",
        workSubline: "لقطات حقيقية من أعمال التركيب والتدريب والدعم الفني داخل المنشآت الصحية.",
        productsTitle: "المنتجات",
        productsSubline: "يمكنك الآن إضافة أو حذف الفئات من لوحة التحكم بدون تعديل الكود.",
        products,
        catalogTitle: "مركز الكتالوجات",
        catalogSubline: "تحميل مباشر لكتالوجات الأجهزة بصيغة PDF.",
        servicesTitle: "الخدمات",
        servicesSubline: "حلول تنفيذية متكاملة من التخطيط وحتى التشغيل الفعلي.",
        services: [
          ["التوريد والتركيب", "تجهيز المشافي والمراكز الصحية بخطط تركيب معتمدة وتسليم تشغيلي كامل."],
          ["التدريب الفني", "تأهيل الكوادر الطبية على التشغيل الصحيح وإجراءات السلامة ومراقبة الجودة."],
          ["الصيانة والدعم", "عقود صيانة دورية، قطع غيار أصلية، وضمان مستمر لاستقرار الأداء."],
        ] as const,
        qualityTitle: "الجودة والشهادات",
        qualitySubline: "الأجهزة المعروضة حاصلة على شهادات عالمية تدعم الاعتماد الرسمي والمناقصات.",
        tenderTitle: "بوابة المناقصات",
        tenderSubline: "قسم محمي للوصول إلى الوثائق القانونية وشهادات الشركاء.",
        tenderPlaceholder: "أدخل كلمة المرور",
        tenderAction: "دخول",
        tenderError: "كلمة المرور غير صحيحة.",
        tenderUnlocked: "تم فتح البوابة. يمكنك الآن تنزيل الملفات:",
        tenderFiles: [
          ["رخصة العمل المترجمة - Shinva", "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"],
          ["تفويض الوكالة الرسمي", "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"],
        ] as const,
        contactTitle: "اتصل بنا",
        contactSubline: "للاستفسارات الفنية والعروض السعرية، تواصل معنا مباشرة.",
        contactAddress: "إدلب، سوريا",
        formName: "الاسم",
        formPhone: "رقم الهاتف",
        formEmail: "البريد الإلكتروني",
        formMessage: "رسالتك",
        formSubmit: "إرسال",
        formSuccess: "تم استلام رسالتك، وسيتم التواصل معك قريباً.",
        adminToggle: "لوحة التحكم",
        adminTitle: "لوحة إدارة المحتوى",
        adminSubline: "تعديل المنتجات والشركات يتم مجانا من المتصفح ويحفظ تلقائيا.",
        adminPasswordLabel: "كلمة مرور الإدارة",
        adminPasswordAction: "دخول الإدارة",
        adminPasswordError: "كلمة المرور غير صحيحة.",
        adminProductsTitle: "إدارة فئات المنتجات",
        adminPartnersTitle: "إدارة الشركات",
        adminMediaTitle: "إدارة الشعار وصور العمل",
        adminLogoLabel: "رابط شعار الشركة",
        adminLogoUpload: "أو ارفع صورة شعار من جهازك",
        adminWorkLabel: "رابط صورة جديدة",
        adminWorkUpload: "أو ارفع صور أعمال من جهازك",
        adminAddWork: "إضافة صورة",
        adminAddPartner: "إضافة شركة",
        adminProductSave: "حفظ الفئة",
        adminProductUpdate: "تحديث الفئة",
        adminDelete: "حذف",
        adminEdit: "تعديل",
        adminReset: "استعادة البيانات الافتراضية",
        adminResetNote: "هذه اللوحة مجانية وتعتمد على Local Storage في نفس الجهاز والمتصفح.",
        footer: "شركة الحكمة للتجهيزات الطبية - جميع الحقوق محفوظة.",
      };
    }

    return {
      dir: "ltr" as const,
      localeLabel: "العربية",
      brand: "Al Hikma Medical Equipment",
      nav: [
        ["partners", "Partners"],
        ["products", "Products"],
        ["projects", "Projects"],
        ["about", "About Us"],
        ["contact", "Contact Us"],
      ] as const,
      heroTitle: "Al Hikma",
      heroHeadline: "Your trusted partner for medical facility setup in Syria",
      heroSubline:
        "Authorized representative of Shinva and Laoken with complete sterilization systems for hospitals and health centers.",
      ctaPrimary: "Explore Products",
      ctaSecondary: "Request Consultation",
      partnersTitle: "Our Partners",
      partnersSubline: "We represent trusted global manufacturers in sterilization and medical equipment.",
      aboutTitle: "About Us",
      aboutBody:
        "Based in Idlib, Syria, Al Hikma bridges the local healthcare sector with modern medical technology through supply, installation, and long-term support.",
      visionTitle: "Vision",
      visionBody: "Deliver leading medical technology to Syrian hospitals and healthcare centers with uncompromising quality.",
      experienceTitle: "Experience and Support",
      experienceBody:
        "We provide technical training for medical and engineering teams, with responsive maintenance and original spare parts availability.",
      managerTitle: "Management Message",
      managerQuote:
        "Al Hikma was established to connect Syria's healthcare sector with the latest global medical innovations. As an authorized agent for manufacturing leaders such as Shinva and Laoken, we are committed to delivering integrated sterilization solutions that ensure top safety standards for patients and healthcare teams.",
      workTitle: "Projects",
      workSubline: "Real snapshots from our installation, technical training, and field support operations.",
      productsTitle: "Products",
      productsSubline: "You can now add or remove product categories from the control panel without code edits.",
      products,
      catalogTitle: "Catalog Center",
      catalogSubline: "Direct PDF downloads for key device catalogs.",
      servicesTitle: "Services",
      servicesSubline: "Execution-ready support from planning to full operation.",
      services: [
        ["Supply and Installation", "Complete hospital setup with approved installation plans and operational handover."],
        ["Technical Training", "Training programs for clinical teams on operation, safety procedures, and quality checks."],
        ["Maintenance and Support", "Periodic maintenance contracts, original spare parts, and warranty-backed support."],
      ] as const,
      qualityTitle: "Quality and Certifications",
      qualitySubline: "Our offered systems carry globally recognized certifications supporting public tenders and approvals.",
      tenderTitle: "Tender Portal",
      tenderSubline: "Protected section for legal partner documents and compliance files.",
      tenderPlaceholder: "Enter password",
      tenderAction: "Access",
      tenderError: "Incorrect password.",
      tenderUnlocked: "Portal unlocked. Download available documents:",
      tenderFiles: [
        ["Translated Business License - Shinva", "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"],
        ["Official Agency Authorization", "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"],
      ] as const,
      contactTitle: "Contact Us",
      contactSubline: "For technical inquiries and quotations, contact us directly.",
      contactAddress: "Idlib, Syria",
      formName: "Name",
      formPhone: "Phone",
      formEmail: "Email",
      formMessage: "Message",
      formSubmit: "Send",
      formSuccess: "Your message has been received. Our team will contact you shortly.",
      adminToggle: "Control Panel",
      adminTitle: "Content Management Panel",
      adminSubline: "Manage products and companies for free in-browser with automatic saving.",
      adminPasswordLabel: "Admin password",
      adminPasswordAction: "Login",
      adminPasswordError: "Incorrect password.",
      adminProductsTitle: "Product Categories",
      adminPartnersTitle: "Companies",
      adminMediaTitle: "Logo and Work Photos",
      adminLogoLabel: "Company logo URL",
      adminLogoUpload: "Or upload a logo image from your device",
      adminWorkLabel: "New photo URL",
      adminWorkUpload: "Or upload work photos from your device",
      adminAddWork: "Add Photo",
      adminAddPartner: "Add Company",
      adminProductSave: "Save Category",
      adminProductUpdate: "Update Category",
      adminDelete: "Delete",
      adminEdit: "Edit",
      adminReset: "Restore Default Data",
      adminResetNote: "This free panel uses Local Storage on the same browser and device.",
      footer: "Al Hikma Medical Equipment - All rights reserved.",
    };
  }, [language, managedProducts]);

  useEffect(() => {
    if (!copy.products.find((item) => item.key === activeProductKey)) {
      setActiveProductKey(copy.products[0]?.key ?? "");
    }
  }, [activeProductKey, copy.products]);

  const activeProduct = copy.products.find((item) => item.key === activeProductKey) ?? copy.products[0];

  const submitPortal = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (portalInput === portalPassword) {
      setPortalUnlocked(true);
      setPortalError(false);
      return;
    }
    setPortalUnlocked(false);
    setPortalError(true);
  };

  const submitMessage = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessageSent(true);
    window.setTimeout(() => setMessageSent(false), 4000);
    (event.currentTarget as HTMLFormElement).reset();
  };

  const submitAdminLogin = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (adminInput === adminPassword) {
      setAdminAuthenticated(true);
      setAdminError(false);
      return;
    }
    setAdminAuthenticated(false);
    setAdminError(true);
  };

  const submitPartner = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const normalized = newPartner.trim();
    if (!normalized || partners.includes(normalized)) {
      return;
    }
    setPartners((prev) => [...prev, normalized]);
    setNewPartner("");
  };

  const startEditProduct = (product: ManagedProduct) => {
    setEditingProductId(product.id);
    setProductDraft({
      titleAr: product.titleAr,
      titleEn: product.titleEn,
      subtitleAr: product.subtitleAr,
      subtitleEn: product.subtitleEn,
      itemsAr: product.itemsAr.join("\n"),
      itemsEn: product.itemsEn.join("\n"),
    });
  };

  const resetDraft = () => {
    setProductDraft(emptyDraft);
    setEditingProductId(null);
  };

  const submitProduct = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const nextProduct: ManagedProduct = {
      id: editingProductId ?? createProductId(productDraft.titleEn || productDraft.titleAr),
      titleAr: productDraft.titleAr.trim(),
      titleEn: productDraft.titleEn.trim(),
      subtitleAr: productDraft.subtitleAr.trim(),
      subtitleEn: productDraft.subtitleEn.trim(),
      itemsAr: productDraft.itemsAr
        .split("\n")
        .map((item) => item.trim())
        .filter(Boolean),
      itemsEn: productDraft.itemsEn
        .split("\n")
        .map((item) => item.trim())
        .filter(Boolean),
    };

    if (!nextProduct.titleAr || !nextProduct.titleEn || nextProduct.itemsAr.length === 0 || nextProduct.itemsEn.length === 0) {
      return;
    }

    if (editingProductId) {
      setManagedProducts((prev) => prev.map((item) => (item.id === editingProductId ? nextProduct : item)));
      resetDraft();
      return;
    }

    setManagedProducts((prev) => {
      const existing = new Set(prev.map((item) => item.id));
      const uniqueId = existing.has(nextProduct.id) ? `${nextProduct.id}-${Date.now()}` : nextProduct.id;
      return [...prev, { ...nextProduct, id: uniqueId }];
    });
    resetDraft();
  };

  const uploadLogoFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }
    try {
      const encoded = await readFileAsDataUrl(file);
      setCompanyLogoUrl(encoded);
    } catch {
      // Ignore failed local file reads to keep admin flow simple.
    } finally {
      event.target.value = "";
    }
  };

  const uploadWorkFiles = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []);
    if (!files.length) {
      return;
    }
    try {
      const encodedFiles = await Promise.all(files.map((file) => readFileAsDataUrl(file)));
      setWorkImages((prev) => [
        ...prev,
        ...encodedFiles.map((src, index) => ({
          id: `work-${Date.now()}-${index}`,
          src,
        })),
      ]);
    } catch {
      // Ignore failed reads and keep existing images untouched.
    } finally {
      event.target.value = "";
    }
  };

  return (
    <div className="bg-white text-slate-900" dir={copy.dir}>
      <header className="fixed inset-x-0 top-0 z-40 border-b border-white/20 bg-slate-950/60 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <a href="#home" className="flex items-center gap-3 text-lg font-semibold tracking-wide text-white">
            <img src={companyLogoUrl} alt={copy.brand} className="h-10 w-10 rounded-full border border-white/50 object-cover" />
            <span>{copy.brand}</span>
          </a>
          <nav className="hidden items-center gap-6 text-sm text-slate-200 md:flex">
            {copy.nav.map(([id, label]) => (
              <a key={id} href={`#${id}`} className="transition hover:text-white">
                {label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setAdminOpen((prev) => !prev)}
              className="rounded-full border border-white/40 px-4 py-1.5 text-sm text-white transition hover:bg-white hover:text-slate-900"
            >
              {copy.adminToggle}
            </button>
            <button
              type="button"
              onClick={() => setLanguage((prev) => (prev === "ar" ? "en" : "ar"))}
              className="rounded-full border border-white/40 px-4 py-1.5 text-sm text-white transition hover:bg-white hover:text-slate-900"
            >
              {copy.localeLabel}
            </button>
          </div>
        </div>
      </header>

      <main>
        <section id="home" className="relative flex min-h-screen items-center overflow-hidden">
          <div className="absolute inset-0">
            {slideImages.map((image, index) => (
              <div
                key={image}
                className={`absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ${
                  index === activeSlide ? "opacity-100" : "opacity-0"
                }`}
                style={{ backgroundImage: `url(${image})` }}
              />
            ))}
            <div className="absolute inset-0 bg-slate-950/65" />
          </div>

          <div className="relative mx-auto w-full max-w-6xl px-6 pt-28 text-white">
            <p className="fade-up text-sm uppercase tracking-[0.3em] text-emerald-200">{copy.heroTitle}</p>
            <h1 className="fade-up mt-4 max-w-4xl text-4xl font-semibold leading-tight md:text-6xl">{copy.heroHeadline}</h1>
            <p className="fade-up mt-5 max-w-2xl text-base text-slate-200 md:text-lg">{copy.heroSubline}</p>
            <div className="fade-up mt-8 flex flex-wrap gap-4">
              <a href="#products" className="rounded-full bg-emerald-500 px-7 py-3 font-medium text-white transition hover:bg-emerald-400">
                {copy.ctaPrimary}
              </a>
              <a
                href="#contact"
                className="rounded-full border border-white/60 px-7 py-3 font-medium text-white transition hover:bg-white hover:text-slate-900"
              >
                {copy.ctaSecondary}
              </a>
            </div>

            <div className="mt-10 flex items-center gap-2">
              {slideImages.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  aria-label={`slide-${index + 1}`}
                  onClick={() => setActiveSlide(index)}
                  className={`h-1.5 rounded-full transition-all ${activeSlide === index ? "w-10 bg-white" : "w-5 bg-white/40"}`}
                />
              ))}
            </div>
          </div>
        </section>

        <section id="partners" className="border-b border-slate-200 py-10 pt-20">
          <div className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-6">
            <h2 className="text-2xl font-semibold text-slate-900">{copy.partnersTitle}</h2>
            <p className="text-slate-600">{copy.partnersSubline}</p>
            <div className="mt-4 overflow-hidden">
              <div className="logo-track">
                {partners.map((partner) => (
                  <div key={partner} className="logo-item">
                    {partner}
                  </div>
                ))}
                {partners.map((partner) => (
                  <div key={`${partner}-copy`} className="logo-item">
                    {partner}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="mx-auto w-full max-w-6xl px-6 py-20">
          <h2 className="text-3xl font-semibold">{copy.aboutTitle}</h2>
          <p className="mt-4 max-w-4xl text-slate-600">{copy.aboutBody}</p>
          <div className="mt-10 grid gap-10 md:grid-cols-2">
            <div>
              <h3 className="text-xl font-semibold text-emerald-700">{copy.visionTitle}</h3>
              <p className="mt-3 text-slate-600">{copy.visionBody}</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-emerald-700">{copy.experienceTitle}</h3>
              <p className="mt-3 text-slate-600">{copy.experienceBody}</p>
            </div>
          </div>
          <blockquote className="mt-12 border-s-4 border-emerald-500 ps-5 text-lg leading-relaxed text-slate-700">
            <p className="font-medium">{copy.managerTitle}</p>
            <p className="mt-2">{copy.managerQuote}</p>
          </blockquote>
        </section>

        <section id="projects" className="mx-auto w-full max-w-6xl px-6 py-20">
          <h2 className="text-3xl font-semibold">{copy.workTitle}</h2>
          <p className="mt-3 text-slate-600">{copy.workSubline}</p>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {workImages.map((image, index) => (
              <img
                key={image.id}
                src={image.src}
                alt={language === "ar" ? `صورة عمل ${index + 1}` : `Work photo ${index + 1}`}
                className="h-64 w-full object-cover"
              />
            ))}
          </div>
        </section>

        <section id="products" className="border-y border-slate-200 bg-slate-50 py-20">
          <div className="mx-auto w-full max-w-6xl px-6">
            <h2 className="text-3xl font-semibold">{copy.productsTitle}</h2>
            <p className="mt-3 text-slate-600">{copy.productsSubline}</p>

            {activeProduct && (
              <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_2fr]">
                <div className="space-y-2">
                  {copy.products.map((product) => (
                    <button
                      key={product.key}
                      type="button"
                      onClick={() => setActiveProductKey(product.key)}
                      className={`w-full border px-4 py-3 text-start transition ${
                        activeProductKey === product.key
                          ? "border-emerald-600 bg-emerald-600 text-white"
                          : "border-slate-300 bg-white hover:border-emerald-500"
                      }`}
                    >
                      <p className="font-medium">{product.title}</p>
                      <p className={`text-sm ${activeProductKey === product.key ? "text-emerald-100" : "text-slate-500"}`}>
                        {product.subtitle}
                      </p>
                    </button>
                  ))}
                </div>

                <div className="border border-slate-300 bg-white p-6">
                  <h3 className="text-2xl font-semibold text-slate-900">{activeProduct.title}</h3>
                  <p className="mt-2 text-slate-600">{activeProduct.subtitle}</p>
                  <ul className="mt-6 space-y-3 text-slate-700">
                    {activeProduct.items.map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <span className="mt-1 h-2 w-2 rounded-full bg-emerald-600" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            <div className="mt-14 border border-slate-300 bg-white p-6">
              <h3 className="text-2xl font-semibold">{copy.catalogTitle}</h3>
              <p className="mt-2 text-slate-600">{copy.catalogSubline}</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <a
                  href="https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-slate-400 px-5 py-2 font-medium transition hover:border-emerald-600 hover:text-emerald-700"
                >
                  NC 100 Catalog (PDF)
                </a>
                <a
                  href="https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-slate-400 px-5 py-2 font-medium transition hover:border-emerald-600 hover:text-emerald-700"
                >
                  Steam Sterilizer Series (PDF)
                </a>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="mx-auto w-full max-w-6xl px-6 py-20">
          <h2 className="text-3xl font-semibold">{copy.servicesTitle}</h2>
          <p className="mt-3 text-slate-600">{copy.servicesSubline}</p>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {copy.services.map(([title, body]) => (
              <div key={title} className="border-t-2 border-emerald-600 pt-4">
                <h3 className="text-xl font-semibold">{title}</h3>
                <p className="mt-3 text-slate-600">{body}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="quality" className="border-y border-slate-200 bg-slate-950 py-20 text-white">
          <div className="mx-auto w-full max-w-6xl px-6">
            <h2 className="text-3xl font-semibold">{copy.qualityTitle}</h2>
            <p className="mt-3 max-w-3xl text-slate-300">{copy.qualitySubline}</p>
            <div className="mt-8 flex flex-wrap gap-4">
              {["CE", "ISO 13485", "EN 285"].map((certificate) => (
                <div key={certificate} className="border border-white/40 px-6 py-3 text-lg font-medium tracking-wide">
                  {certificate}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="tender" className="mx-auto w-full max-w-6xl px-6 py-20">
          <h2 className="text-3xl font-semibold">{copy.tenderTitle}</h2>
          <p className="mt-3 text-slate-600">{copy.tenderSubline}</p>
          <form onSubmit={submitPortal} className="mt-8 flex flex-wrap items-center gap-3 border border-slate-300 p-4">
            <input
              value={portalInput}
              onChange={(event) => setPortalInput(event.target.value)}
              type="password"
              required
              className="min-w-56 flex-1 border border-slate-300 px-4 py-2"
              placeholder={copy.tenderPlaceholder}
            />
            <button type="submit" className="bg-slate-900 px-5 py-2.5 font-medium text-white transition hover:bg-slate-700">
              {copy.tenderAction}
            </button>
          </form>
          {portalError && <p className="mt-3 text-red-600">{copy.tenderError}</p>}
          {portalUnlocked && (
            <div className="mt-5 border border-emerald-400 bg-emerald-50 p-5 text-slate-800">
              <p className="font-medium">{copy.tenderUnlocked}</p>
              <div className="mt-3 flex flex-col gap-2">
                {copy.tenderFiles.map(([label, href]) => (
                  <a key={label} href={href} target="_blank" rel="noreferrer" className="underline underline-offset-4">
                    {label}
                  </a>
                ))}
              </div>
            </div>
          )}
        </section>

        <section id="contact" className="border-t border-slate-200 bg-slate-50 py-20">
          <div className="mx-auto grid w-full max-w-6xl gap-10 px-6 md:grid-cols-2">
            <div>
              <h2 className="text-3xl font-semibold">{copy.contactTitle}</h2>
              <p className="mt-3 text-slate-600">{copy.contactSubline}</p>
              <div className="mt-6 space-y-3 text-slate-700">
                <p>{copy.contactAddress}</p>
                <p>+963 955 000 000</p>
                <p>info@alhikma-med.com</p>
              </div>
            </div>

            <form onSubmit={submitMessage} className="space-y-3 border border-slate-300 bg-white p-5">
              <input required placeholder={copy.formName} className="w-full border border-slate-300 px-4 py-2" />
              <input required placeholder={copy.formPhone} className="w-full border border-slate-300 px-4 py-2" />
              <input type="email" required placeholder={copy.formEmail} className="w-full border border-slate-300 px-4 py-2" />
              <textarea required placeholder={copy.formMessage} rows={4} className="w-full border border-slate-300 px-4 py-2" />
              <button type="submit" className="w-full bg-emerald-600 px-5 py-2.5 font-medium text-white transition hover:bg-emerald-500">
                {copy.formSubmit}
              </button>
              {messageSent && <p className="text-sm text-emerald-700">{copy.formSuccess}</p>}
            </form>
          </div>
        </section>

        {adminOpen && (
          <section className="border-t border-slate-200 bg-white py-16">
            <div className="mx-auto w-full max-w-6xl px-6">
              <h2 className="text-3xl font-semibold">{copy.adminTitle}</h2>
              <p className="mt-2 text-slate-600">{copy.adminSubline}</p>

              {!adminAuthenticated ? (
                <form onSubmit={submitAdminLogin} className="mt-8 max-w-xl space-y-3 border border-slate-300 p-5">
                  <label className="block text-sm font-medium text-slate-700">{copy.adminPasswordLabel}</label>
                  <input
                    type="password"
                    required
                    value={adminInput}
                    onChange={(event) => setAdminInput(event.target.value)}
                    className="w-full border border-slate-300 px-4 py-2"
                  />
                  <button type="submit" className="bg-slate-900 px-5 py-2.5 font-medium text-white transition hover:bg-slate-700">
                    {copy.adminPasswordAction}
                  </button>
                  {adminError && <p className="text-sm text-red-600">{copy.adminPasswordError}</p>}
                </form>
              ) : (
                <div className="mt-8 space-y-10">
                  <div className="border border-slate-300 p-5">
                    <h3 className="text-2xl font-semibold">{copy.adminProductsTitle}</h3>
                    <div className="mt-5 space-y-3">
                      {managedProducts.map((product) => (
                        <div key={product.id} className="flex flex-wrap items-center justify-between gap-3 border border-slate-200 p-3">
                          <p className="font-medium">
                            {product.titleAr} / {product.titleEn}
                          </p>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => startEditProduct(product)}
                              className="border border-slate-400 px-3 py-1.5 text-sm transition hover:border-slate-700"
                            >
                              {copy.adminEdit}
                            </button>
                            <button
                              type="button"
                              onClick={() => setManagedProducts((prev) => prev.filter((item) => item.id !== product.id))}
                              className="border border-red-400 px-3 py-1.5 text-sm text-red-700 transition hover:border-red-600"
                            >
                              {copy.adminDelete}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <form onSubmit={submitProduct} className="mt-6 grid gap-3 md:grid-cols-2">
                      <input
                        required
                        value={productDraft.titleAr}
                        onChange={(event) => setProductDraft((prev) => ({ ...prev, titleAr: event.target.value }))}
                        placeholder="العنوان العربي"
                        className="border border-slate-300 px-4 py-2"
                      />
                      <input
                        required
                        value={productDraft.titleEn}
                        onChange={(event) => setProductDraft((prev) => ({ ...prev, titleEn: event.target.value }))}
                        placeholder="English title"
                        className="border border-slate-300 px-4 py-2"
                      />
                      <input
                        value={productDraft.subtitleAr}
                        onChange={(event) => setProductDraft((prev) => ({ ...prev, subtitleAr: event.target.value }))}
                        placeholder="الوصف العربي القصير"
                        className="border border-slate-300 px-4 py-2"
                      />
                      <input
                        value={productDraft.subtitleEn}
                        onChange={(event) => setProductDraft((prev) => ({ ...prev, subtitleEn: event.target.value }))}
                        placeholder="Short English subtitle"
                        className="border border-slate-300 px-4 py-2"
                      />
                      <textarea
                        required
                        rows={5}
                        value={productDraft.itemsAr}
                        onChange={(event) => setProductDraft((prev) => ({ ...prev, itemsAr: event.target.value }))}
                        placeholder="نقاط المنتج بالعربي (كل سطر نقطة)"
                        className="border border-slate-300 px-4 py-2"
                      />
                      <textarea
                        required
                        rows={5}
                        value={productDraft.itemsEn}
                        onChange={(event) => setProductDraft((prev) => ({ ...prev, itemsEn: event.target.value }))}
                        placeholder="English bullets (one line per bullet)"
                        className="border border-slate-300 px-4 py-2"
                      />
                      <div className="md:col-span-2 flex flex-wrap gap-2">
                        <button type="submit" className="bg-emerald-600 px-5 py-2.5 font-medium text-white transition hover:bg-emerald-500">
                          {editingProductId ? copy.adminProductUpdate : copy.adminProductSave}
                        </button>
                        {editingProductId && (
                          <button
                            type="button"
                            onClick={resetDraft}
                            className="border border-slate-400 px-5 py-2.5 font-medium transition hover:border-slate-700"
                          >
                            {language === "ar" ? "إلغاء" : "Cancel"}
                          </button>
                        )}
                      </div>
                    </form>
                  </div>

                  <div className="border border-slate-300 p-5">
                    <h3 className="text-2xl font-semibold">{copy.adminPartnersTitle}</h3>
                    <form onSubmit={submitPartner} className="mt-4 flex flex-wrap gap-2">
                      <input
                        value={newPartner}
                        onChange={(event) => setNewPartner(event.target.value)}
                        placeholder={language === "ar" ? "اسم الشركة" : "Company name"}
                        className="min-w-56 flex-1 border border-slate-300 px-4 py-2"
                      />
                      <button type="submit" className="bg-slate-900 px-5 py-2.5 font-medium text-white transition hover:bg-slate-700">
                        {copy.adminAddPartner}
                      </button>
                    </form>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {partners.map((partner) => (
                        <div key={partner} className="flex items-center gap-2 border border-slate-300 px-3 py-1.5">
                          <span>{partner}</span>
                          <button
                            type="button"
                            onClick={() => setPartners((prev) => prev.filter((item) => item !== partner))}
                            className="text-sm text-red-600"
                          >
                            {copy.adminDelete}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border border-slate-300 p-5">
                    <h3 className="text-2xl font-semibold">{copy.adminMediaTitle}</h3>
                    <div className="mt-4 space-y-3">
                      <label className="block text-sm font-medium text-slate-700">{copy.adminLogoLabel}</label>
                      <input
                        value={companyLogoUrl}
                        onChange={(event) => setCompanyLogoUrl(event.target.value)}
                        className="w-full border border-slate-300 px-4 py-2"
                        placeholder="https://..."
                      />
                      <label className="block text-sm font-medium text-slate-700">{copy.adminLogoUpload}</label>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={uploadLogoFile}
                        className="w-full border border-slate-300 px-3 py-2"
                      />
                    </div>

                    <form
                      onSubmit={(event) => {
                        event.preventDefault();
                        const normalized = newWorkImage.trim();
                        if (!normalized) {
                          return;
                        }
                        setWorkImages((prev) => [...prev, { id: `work-${Date.now()}`, src: normalized }]);
                        setNewWorkImage("");
                      }}
                      className="mt-5 flex flex-wrap gap-2"
                    >
                      <input
                        value={newWorkImage}
                        onChange={(event) => setNewWorkImage(event.target.value)}
                        placeholder={copy.adminWorkLabel}
                        className="min-w-56 flex-1 border border-slate-300 px-4 py-2"
                      />
                      <button type="submit" className="bg-slate-900 px-5 py-2.5 font-medium text-white transition hover:bg-slate-700">
                        {copy.adminAddWork}
                      </button>
                    </form>

                    <div className="mt-3">
                      <label className="block text-sm font-medium text-slate-700">{copy.adminWorkUpload}</label>
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={uploadWorkFiles}
                        className="mt-2 w-full border border-slate-300 px-3 py-2"
                      />
                    </div>

                    <div className="mt-4 grid gap-3 md:grid-cols-3">
                      {workImages.map((image, index) => (
                        <div key={image.id} className="space-y-2 border border-slate-300 p-2">
                          <img
                            src={image.src}
                            alt={language === "ar" ? `صورة عمل ${index + 1}` : `Work photo ${index + 1}`}
                            className="h-28 w-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={() => setWorkImages((prev) => prev.filter((item) => item.id !== image.id))}
                            className="w-full border border-red-400 px-3 py-1.5 text-sm text-red-700 transition hover:border-red-600"
                          >
                            {copy.adminDelete}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border border-amber-300 bg-amber-50 p-5">
                    <p className="text-sm text-amber-900">{copy.adminResetNote}</p>
                    <button
                      type="button"
                      onClick={() => {
                        setManagedProducts(defaultProducts);
                        setPartners(defaultPartners);
                        setCompanyLogoUrl(defaultCompanyLogo);
                        setWorkImages(defaultWorkImages);
                        setNewWorkImage("");
                        resetDraft();
                      }}
                      className="mt-3 border border-amber-500 px-4 py-2 text-sm font-medium text-amber-900 transition hover:bg-amber-100"
                    >
                      {copy.adminReset}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </section>
        )}
      </main>

      <footer className="bg-slate-950 px-6 py-6 text-center text-sm text-slate-300">{copy.footer}</footer>
    </div>
  );
}
